package progetto.mp.bollecchino.matteo;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public final class Library {
	private String name;
	private String city;
	private List<LibraryItem> items;
	private boolean offerSubscription;
	private int floors;

	private Library() {
	}
	
	private void setName(String name) {
		this.name = name;
	}

	private void setCity(String city) {
		this.city = city;
	}

	private void setItems(List<LibraryItem> items) {
		this.items = items;
	}

	private void setOfferSubscription(boolean offerSubscription) {
		this.offerSubscription = offerSubscription;
	}

	private void setFloors(int floors) {
		this.floors = floors;
	}
	
	String getName() {
		return name;
	}

	String getCity() {
		return city;
	}

	List<LibraryItem> getItems() {
		return items;
	}
	
	boolean isOfferSubscription() {
		return offerSubscription;
	}
	
	int getFloors() {
		return floors;
	}
	
	public static class LibraryBuilder {
		private String name;
		private String city;
		private List<LibraryItem> items;
		private boolean offerSubscription;
		private int floors;

		public LibraryBuilder(String name, String city) {
			this.name = name;
			this.city = city;
		}
		
		public LibraryBuilder withItems(List<LibraryItem> items) {
			if(items==null)
				throw new IllegalArgumentException("The provided collection of items "
						+ "isn't acceptable");
			this.items=items;
			return this;
		}
		
		public LibraryBuilder withOfferSubscription(boolean offerSubscription) {
			this.offerSubscription = offerSubscription;
			return this;
		}
		
		public LibraryBuilder withFloors(int floors) {
			if(floors<=0)
				throw new IllegalArgumentException("The library has to have at least"
						+ " one floor");
			this.floors=floors;
			return this;
		}
		
		public Library build() {
			Library library = new Library();
			library.setName(name);
			library.setCity(city);
			library.setItems(items);
			library.setOfferSubscription(offerSubscription);
			library.setFloors(floors);
			return library;
		}
	}
	
	public void sortItemsByTitle()
	{
		items.sort((i1,i2) -> i1.getTitle().compareTo(i2.getTitle()));
	}
	
	public Optional<LibraryItem> findByTitle(String title)
	{
		return items.stream()
				.filter(item -> item.getTitle().equalsIgnoreCase(title))
				.findFirst();
	}
	
	public Collection<Optional<LibraryItem>> findByAuthor(String author, 
			Collection<Optional<LibraryItem>> found)
	{
		AuthorFilter filter = new AuthorFilter(author);
		items.forEach(item -> {item.accept(filter);
								found.add(filter.getItem());});
		
		return found.stream()
				.filter(item -> item.isPresent())
				.collect(Collectors.toList());
	}
	
	public Collection<LibraryItem> findAvailableItems()
	{
		return items.stream()
				.filter(item -> item.isAvailable())
				.collect(Collectors.toList());
	}
	
	private class AuthorFilter implements LibraryItemVisitor{
		private String author;
		private Optional<LibraryItem> item;
		
		public AuthorFilter(String author) {
			this.author = author;
		}

		@Override
		public void visitBook(Book book) {
			if(book.getAuthor().equalsIgnoreCase(author))
				item=Optional.of(book);
			else
				item=Optional.empty();
		}

		@Override
		public void visitComic(Comic comic) {
			if(comic.getAuthor().equalsIgnoreCase(author))
				item=Optional.of(comic);
			else
				item=Optional.empty();
		}

		@Override
		public void visitVhs(Vhs vhs) {
			item=Optional.empty();
		}

		public Optional<LibraryItem> getItem() {
			return item;
		}
	}
}
