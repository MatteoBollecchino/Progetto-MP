package progetto.mp.bollecchino.matteo;

import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public class Book extends LibraryItem {
	private String author;
	private String state;

	public Book(String title, int yearRelease, boolean available, String author, String state) {
		super(title, yearRelease, available);
		this.author = author;
		this.state=state;
	}

	public String getAuthor() {
		return author;
	}
	
	public String getState() {
		return state;
	}
	
	private void setState(String state) {
		this.state = state;
	}
	
	public void changeState(String newState) {
		if(!state.equalsIgnoreCase(newState)) {
			setState(newState);
			notifyObservers(this, isAvailable());
		}
	}

	@Override
	public void accept(LibraryItemVisitor visitor) {
		visitor.visitBook(this);
	}
}