package progetto.mp.bollecchino.matteo;

import java.util.ArrayList;
import java.util.Collection;

import progetto.mp.bollecchino.matteo.observer.LibraryItemObserver;
import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public abstract class LibraryItem {
	private String title;
	private int yearRelease;
	private boolean available;
	private Collection<LibraryItemObserver> observers = new ArrayList<>();

	public LibraryItem(String title, int yearRelease, boolean available) {
		this.title = title;
		this.yearRelease = yearRelease;
		this.available = available;
	}
	
	private void setAvailable(boolean available) {
		this.available=available;
	}
	
	public void changeAvailable(boolean available) {
		if(this.available!=available){
			setAvailable(available);
			notifyObservers(this, available);
		}
		else {
			throw new IllegalArgumentException("The operation doesn't change "
					+ "the disponibility of the item");
		}
	}

	public String getTitle() {
		return title;
	}

	int getYearRelease() {
		return yearRelease;
	}

	public boolean isAvailable() {
		return available;
	}
	
	public abstract void accept(LibraryItemVisitor visitor);
	
	public void attachObserver(LibraryItemObserver obs) {
		observers.add(obs);
	}
	
	public void detachObserver(LibraryItemObserver obs) {
		observers.remove(obs);
	}
	
	protected void notifyObservers(LibraryItem item, boolean available) {
		observers.forEach(obs -> obs.update(item, available));
	}
	
	Collection<LibraryItemObserver> getObservers() {
		return observers;
	}
}