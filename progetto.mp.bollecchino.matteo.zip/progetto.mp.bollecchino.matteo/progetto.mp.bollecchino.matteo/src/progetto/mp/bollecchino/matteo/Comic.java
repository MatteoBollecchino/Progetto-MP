package progetto.mp.bollecchino.matteo;

import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public class Comic extends LibraryItem {
	private String author;
	private String periodicity;

	public Comic(String title, int yearRelease, boolean available, String author,
			String periodicity) {
		super(title, yearRelease, available);
		this.author = author;
		this.periodicity = periodicity;
	}
	
	public String getAuthor() {
		return author;
	}

	String getPeriodicity() {
		return periodicity;
	}

	@Override
	public void accept(LibraryItemVisitor visitor) {
		visitor.visitComic(this);
	}
}