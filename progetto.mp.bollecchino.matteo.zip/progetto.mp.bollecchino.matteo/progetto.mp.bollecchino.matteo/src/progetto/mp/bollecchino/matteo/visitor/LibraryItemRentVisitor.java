package progetto.mp.bollecchino.matteo.visitor;

import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.utils.LibraryItemPrinter;

public class LibraryItemRentVisitor implements LibraryItemVisitor {
	private LibraryItemPrinter printer;

	public LibraryItemRentVisitor(LibraryItemPrinter printer) {
		this.printer = printer;
	}

	@Override
	public void visitBook(Book book) {
		commonVisit(book);
	}

	@Override
	public void visitComic(Comic comic) {
		commonVisit(comic);
	}

	@Override
	public void visitVhs(Vhs dvd) {
		commonVisit(dvd);
	}
	
	private void commonVisit(LibraryItem item) {
		if(!item.isAvailable())
			printer.print(item.getTitle()+" is already rented");
		else
			printer.print(item.getTitle()+" is not rented");
	}
}
