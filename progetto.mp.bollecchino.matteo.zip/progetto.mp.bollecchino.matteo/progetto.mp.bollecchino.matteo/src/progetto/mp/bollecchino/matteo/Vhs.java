package progetto.mp.bollecchino.matteo;

import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public class Vhs extends LibraryItem {
	private boolean rewound;

	public Vhs(String title, int yearRelease, boolean available, boolean rewound) {
		super(title,yearRelease,available);
		this.rewound = rewound;
	}
	
	boolean isRewound() {
		return rewound;
	}

	@Override
	public void accept(LibraryItemVisitor visitor) {
		visitor.visitVhs(this);
	}
}