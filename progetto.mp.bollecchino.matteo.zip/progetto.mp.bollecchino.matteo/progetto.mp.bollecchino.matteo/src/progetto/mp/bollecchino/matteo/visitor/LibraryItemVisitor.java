package progetto.mp.bollecchino.matteo.visitor;

import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;

public interface LibraryItemVisitor {
	void visitBook(Book book);
	
	void visitComic(Comic comic);
	
	void visitVhs(Vhs vhs);
}
