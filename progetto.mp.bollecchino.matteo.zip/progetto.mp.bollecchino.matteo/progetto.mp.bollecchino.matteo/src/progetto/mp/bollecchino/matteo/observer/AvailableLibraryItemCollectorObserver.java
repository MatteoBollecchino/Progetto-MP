package progetto.mp.bollecchino.matteo.observer;

import java.util.Collection; 
import progetto.mp.bollecchino.matteo.LibraryItem;

public class AvailableLibraryItemCollectorObserver implements LibraryItemObserver {
	private Collection<LibraryItem> availableItems;

	public AvailableLibraryItemCollectorObserver(Collection<LibraryItem> availableItems) {
		this.availableItems = availableItems;
	}
	
	@Override
	public void update(LibraryItem item, boolean available) {
		if(available && !availableItems.contains(item))
			availableItems.add(item);
		if(!available)
			availableItems.remove(item);
	}
	
	public Collection<LibraryItem> getCollection() {
		return availableItems;
	}
}
