package progetto.mp.bollecchino.matteo.observer;

import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.utils.LibraryItemPrinter;
import progetto.mp.bollecchino.matteo.visitor.LibraryItemRentVisitor;

public class DisponibilityObserver implements LibraryItemObserver {
	private LibraryItemPrinter printer;
	private boolean available;

	public DisponibilityObserver(LibraryItemPrinter printer) {
		this.printer = printer;
	}
	
	@Override
	public void update(LibraryItem item, boolean available) {
		this.available = available;
		item.accept(new LibraryItemRentVisitor(printer));
	}

	public boolean isAvailable() {
		return available;
	}
}