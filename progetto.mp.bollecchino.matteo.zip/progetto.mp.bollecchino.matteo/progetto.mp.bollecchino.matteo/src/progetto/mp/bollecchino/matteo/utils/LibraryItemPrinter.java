package progetto.mp.bollecchino.matteo.utils;

public interface LibraryItemPrinter {
	void print(String message);
}
