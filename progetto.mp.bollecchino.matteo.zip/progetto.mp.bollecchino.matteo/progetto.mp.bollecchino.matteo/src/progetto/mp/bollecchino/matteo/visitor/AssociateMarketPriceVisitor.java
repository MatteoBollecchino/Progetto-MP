package progetto.mp.bollecchino.matteo.visitor;

import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.utils.LibraryItemPrinter;

public class AssociateMarketPriceVisitor implements LibraryItemVisitor {
	private LibraryItemPrinter printer;
	private double price;

	public AssociateMarketPriceVisitor(LibraryItemPrinter printer,double price) {
		this.printer = printer;
		this.price = price;
	}
	
	@Override
	public void visitBook(Book book) {
		printer.print(
				"The book "+book.getTitle()+" is "+ price + " euros on the market");
	}

	@Override
	public void visitComic(Comic comic) {
		printer.print(
				"The comic "+comic.getTitle()+" is "+ price + " euros on the market");
	}

	@Override
	public void visitVhs(Vhs vhs) {
		printer.print(
				"The vhs "+vhs.getTitle()+" is "+ price + " euros on the market");
	}

	double getPrice() {
		return price;
	}
}
