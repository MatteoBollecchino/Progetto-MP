package progetto.mp.bollecchino.matteo.observer;

import progetto.mp.bollecchino.matteo.LibraryItem;

public interface LibraryItemObserver {
	void update(LibraryItem item, boolean available);
}
