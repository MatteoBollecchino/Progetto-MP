package progetto.mp.bollecchino.matteo.observer;

import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.visitor.LibraryItemVisitor;

public class BookStateObserver implements LibraryItemObserver {
	private String currentState;

	public BookStateObserver(String currentState) {
		this.currentState = currentState;
	}
	
	@Override
	public void update(LibraryItem item, boolean lent) {
		item.accept(new LibraryItemVisitor() {
			
			@Override
			public void visitVhs(Vhs vhs) {
			}
			
			@Override
			public void visitComic(Comic comic) {
			}
			
			@Override
			public void visitBook(Book book) {
				if(book.getState()!=currentState) 
					currentState=book.getState();
			}
		});
	}
	
	public String getCurrentState() {
		return currentState;
	}
}
