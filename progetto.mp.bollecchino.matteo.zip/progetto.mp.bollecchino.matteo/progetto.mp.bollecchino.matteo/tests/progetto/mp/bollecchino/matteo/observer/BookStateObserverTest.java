package progetto.mp.bollecchino.matteo.observer;

import static org.junit.Assert.assertEquals; 

import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;

public class BookStateObserverTest {
	BookStateObserver obs;
	
	@Before
	public void init() {
		obs = new BookStateObserver("Unknown");
	}

	@Test
	public void testBookStateChanged() {
		Book book = new Book("1984", 1949, false, "George Orwell","good");
		book.attachObserver(obs);
		book.changeState("bad");
		
		assertEquals("bad",obs.getCurrentState());
	}
	
	@Test
	public void testBookStateNotChanged() {
		Book book = new Book("1984", 1949, true, "George Orwell","good");
		book.attachObserver(obs);
		book.changeState("bad");
		
		assertEquals("bad",obs.getCurrentState());
		
		book.changeState("bad");
		
		assertEquals("bad",obs.getCurrentState());
	}
	
	@Test
	public void testBookStateObserverWithVhs() {
		Vhs vhs = new Vhs("Cars", 2006, false, false);
		
		vhs.attachObserver(obs);
		vhs.changeAvailable(true);
		
		assertEquals("Unknown",obs.getCurrentState());
	}
	
	@Test
	public void testBookStateObserverWithComic() {
		Comic comic = new Comic("One Piece", 1997, true, "Eichiro Oda", "weekly");
		
		comic.attachObserver(obs);
		comic.changeAvailable(false);
		
		assertEquals("Unknown",obs.getCurrentState());
	}
	
	@Test
	public void testBookStateObserverAfterChangingDisponibility() {
		Book book = new Book("1984", 1949, true, "George Orwell","good");
		book.attachObserver(obs);
		book.changeAvailable(false);
		
		assertEquals("good", obs.getCurrentState());
		
		book.changeState("quite good");
		
		assertEquals("quite good", obs.getCurrentState());
	}
	
	@Test
	public void testBookStateObserverAfterDetaching() {
		Book book = new Book("1984", 1949, false, "George Orwell","good");
		book.attachObserver(obs);
		book.changeState("bad");
		
		assertEquals("bad", obs.getCurrentState());
		
		book.detachObserver(obs);
		book.changeState("horrible");
		
		assertEquals("bad", obs.getCurrentState());
	}
}
