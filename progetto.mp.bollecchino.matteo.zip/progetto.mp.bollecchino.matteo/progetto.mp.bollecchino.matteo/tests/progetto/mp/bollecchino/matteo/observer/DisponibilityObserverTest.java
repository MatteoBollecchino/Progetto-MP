package progetto.mp.bollecchino.matteo.observer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.utils.MockLibraryItemPrinter;

public class DisponibilityObserverTest {
	private DisponibilityObserver obs;
	private LibraryItem item;
	private MockLibraryItemPrinter printer;
	
	@Before
	public void init() {
		printer = new MockLibraryItemPrinter();
		obs = new DisponibilityObserver(printer);
		item = new Vhs("Cars", 2006, false, false);
		item.attachObserver(obs);
	}

	@Test
	public void testChangeDisponibilityLibraryItem() {
		item.changeAvailable(true);
		
		assertEquals(item.getTitle()+" is not rented",
				printer.getMessage());
		assertTrue(obs.isAvailable());
	}
	
	@Test
	public void testDetachDisponibilityObserver() {
		item.changeAvailable(true);
				
		assertEquals(item.getTitle()+" is not rented",
				printer.getMessage());
		assertTrue(obs.isAvailable());
		
		item.detachObserver(obs);
		item.changeAvailable(false);
		
		assertEquals(item.getTitle()+" is not rented",
				printer.getMessage());
		assertTrue(obs.isAvailable());
	}
}
