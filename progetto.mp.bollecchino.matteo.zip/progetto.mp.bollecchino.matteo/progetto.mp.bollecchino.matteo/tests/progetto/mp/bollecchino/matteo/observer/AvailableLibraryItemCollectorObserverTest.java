package progetto.mp.bollecchino.matteo.observer;

import static org.assertj.core.api.Assertions.assertThat; 
import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;

public class AvailableLibraryItemCollectorObserverTest {
	private AvailableLibraryItemCollectorObserver obs;
	private Comic item1;
	private Book item2;
	private Vhs item3;

	@Before
	public void init() {
		this.obs= new AvailableLibraryItemCollectorObserver(
				new ArrayList<LibraryItem>());
		item1 = new Comic("Naruto", 1999, false, "Masashi Kishimoto", "every 3 moths");
		item2 = new Book("1984", 1949, true, "George Orwell","good");
		item3 = new Vhs("Cars", 2006, false, false);
	}

	@Test
	public void testAddingAvailableItem() {
		item1.attachObserver(obs);
		
		item1.changeAvailable(true);
		
		assertThat(obs.getCollection()).contains(item1);
		
		item1.changeAvailable(false);
		
		assertThat(obs.getCollection()).isEmpty();
	}
	
	@Test
	public void testObserverCollectionAfterDetaching1() {
		item1.attachObserver(obs);
		item1.changeAvailable(true);
		
		assertThat(obs.getCollection()).contains(item1);
		
		item1.detachObserver(obs);
		item1.changeAvailable(false);
		
		assertThat(obs.getCollection()).contains(item1);
	}
	
	@Test
	public void testObserverCollectionAfterDetaching2() {
		item1.changeAvailable(true);
		
		item1.attachObserver(obs);
		item1.changeAvailable(false);
		
		assertThat(obs.getCollection()).isEmpty();
		
		item1.detachObserver(obs);
		item1.changeAvailable(true);
		
		assertThat(obs.getCollection()).isEmpty();
	}
	
	@Test
	public void testObserverCollectionWithMultipleItems() {
		item1.attachObserver(obs);
		item2.attachObserver(obs);
		item3.attachObserver(obs);
		
		item1.changeAvailable(true);
		item2.changeAvailable(false);
		item3.changeAvailable(true);
		
		assertThat(obs.getCollection())
			.containsExactlyInAnyOrder(item1,item3);
		
		item1.changeAvailable(false);
		item1.changeAvailable(true);
		
		assertThat(obs.getCollection())
			.containsExactlyInAnyOrder(item1,item3);
		
		item3.changeAvailable(false);
		item2.changeAvailable(true);
		
		assertThat(obs.getCollection())
			.containsExactlyInAnyOrder(item1,item2);
	}
	
	@Test
	public void testObserverCollectionWithMultipleItemsAfterDetaching() {
		item1.attachObserver(obs);
		item2.attachObserver(obs);
		item3.attachObserver(obs);
		
		item1.changeAvailable(true);
		item2.changeAvailable(false);
		item3.changeAvailable(true);
		
		assertThat(obs.getCollection())
			.containsExactlyInAnyOrder(item1,item3);
		
		item1.detachObserver(obs);
		item2.detachObserver(obs);
		item3.detachObserver(obs);
		
		item1.changeAvailable(false);
		item2.changeAvailable(true);
		item3.changeAvailable(false);
		
		assertThat(obs.getCollection())
			.containsExactlyInAnyOrder(item1,item3);
	}
}
