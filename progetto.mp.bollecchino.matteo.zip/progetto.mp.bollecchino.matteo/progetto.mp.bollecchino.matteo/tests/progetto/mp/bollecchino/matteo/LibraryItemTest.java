package progetto.mp.bollecchino.matteo;

import static org.assertj.core.api.Assertions.assertThat; 
import static org.junit.Assert.assertThrows;
import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.observer.LibraryItemObserver;

public class LibraryItemTest {
	private LibraryItem item;
	private LibraryItemObserver obs1;
	private LibraryItemObserver obs2;
	
	@Before
	public void init() {
		item = new Book("1984", 1949, false, "George Orwell","good");
		obs1 = new MockItemObserver();
		obs2 = new MockItemObserver();
	}

	@Test
	public void testAttachObserverToLibraryItem() {
		item.attachObserver(obs1);
		item.attachObserver(obs2);
		
		assertThat(item.getObservers()).containsExactlyInAnyOrder(obs1,obs2);
	}
	
	@Test
	public void testDetachObserverFromLibraryItem() {
		item.attachObserver(obs1);
		item.attachObserver(obs2);
		
		assertThat(item.getObservers()).containsExactlyInAnyOrder(obs1,obs2);
		
		item.detachObserver(obs2);
		
		assertThat(item.getObservers()).doesNotContain(obs2);
		assertThat(item.getObservers()).contains(obs1);
	}
	
	@Test
	public void testChangeDisponibilityOfLibraryItem() {
		item.attachObserver(obs1);
		
		item.changeAvailable(true);
		
		LibraryItem itemObs = ((MockItemObserver) obs1).getItem();
		boolean availableObs = ((MockItemObserver) obs1).isAvailable();
		
		assertThat(item.isAvailable()).isTrue();
		assertThat(itemObs).isSameAs(item);
		assertThat(availableObs).isEqualTo(item.isAvailable());
		
		item.detachObserver(obs1);
		
		item.changeAvailable(false);
		
		itemObs = ((MockItemObserver) obs1).getItem();
		availableObs = ((MockItemObserver) obs1).isAvailable();
		
		assertThat(item.isAvailable()).isFalse();
		assertThat(itemObs).isSameAs(item);
		assertThat(availableObs).isNotEqualTo(item.isAvailable());
	}
	
	@Test
	public void testIncorrectChangeDisponibilityOfLibraryItem() {
		assertThrows(IllegalArgumentException.class, 
				() -> item.changeAvailable(false));
		
		item.changeAvailable(true);
		
		assertThrows(IllegalArgumentException.class, 
				() -> item.changeAvailable(true));
	}
}
