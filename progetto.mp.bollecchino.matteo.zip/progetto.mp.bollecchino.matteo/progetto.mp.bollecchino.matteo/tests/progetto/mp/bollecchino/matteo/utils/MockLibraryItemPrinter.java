package progetto.mp.bollecchino.matteo.utils;

public class MockLibraryItemPrinter implements LibraryItemPrinter {
	private StringBuilder builder = new StringBuilder();
	
	@Override
	public void print(String message) {
		builder.append(message);
	}

	public String getMessage() {
		return builder.toString();
	}
}
