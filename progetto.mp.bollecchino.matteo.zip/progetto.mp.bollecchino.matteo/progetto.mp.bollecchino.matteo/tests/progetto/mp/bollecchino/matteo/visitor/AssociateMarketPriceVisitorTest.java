package progetto.mp.bollecchino.matteo.visitor;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.utils.MockLibraryItemPrinter;

public class AssociateMarketPriceVisitorTest {
	private AssociateMarketPriceVisitor visitor;
	private MockLibraryItemPrinter printer;
	
	@Before 
	public void init() {
		this.printer = new MockLibraryItemPrinter();
		this.visitor = new AssociateMarketPriceVisitor(printer,5.99);
	}
	
	@Test
	public void testAssociatingPriceToBook() {
		LibraryItem book = new Book("1984", 1949, false, "George Orwell","good");
		
		book.accept(visitor);
		assertEquals(printer.getMessage(), 
				"The book "+book.getTitle()+" is "+ visitor.getPrice() + " euros on the market");
	}
	
	@Test
	public void testAssociatingPriceToComic() {
		LibraryItem comic = new Comic("Naruto", 1999, true, "Masashi Kishimoto", "every 3 moths");
		
		comic.accept(visitor);
		assertEquals(printer.getMessage(), 
				"The comic "+comic.getTitle()+" is "+ visitor.getPrice() + " euros on the market");
	}
	
	@Test
	public void testAssociatingPriceToVhs() {
		LibraryItem vhs = new Vhs("John Wick", 2014, true, false);
		
		vhs.accept(visitor);
		assertEquals(printer.getMessage(), 
				"The vhs "+vhs.getTitle()+" is "+ visitor.getPrice() + " euros on the market");
	}
}
