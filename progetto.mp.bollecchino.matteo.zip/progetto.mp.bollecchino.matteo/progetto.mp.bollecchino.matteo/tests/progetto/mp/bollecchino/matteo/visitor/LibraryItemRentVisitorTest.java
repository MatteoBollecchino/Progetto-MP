package progetto.mp.bollecchino.matteo.visitor;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import progetto.mp.bollecchino.matteo.Book;
import progetto.mp.bollecchino.matteo.Comic;
import progetto.mp.bollecchino.matteo.Vhs;
import progetto.mp.bollecchino.matteo.LibraryItem;
import progetto.mp.bollecchino.matteo.utils.MockLibraryItemPrinter;

public class LibraryItemRentVisitorTest {
	private MockLibraryItemPrinter printer;
	private LibraryItemRentVisitor visitor;
	
	@Before
	public void init() {
		this.printer = new MockLibraryItemPrinter();
		this.visitor = new LibraryItemRentVisitor(printer);
	}

	@Test
	public void testIfBookIsAlreadyRented() {
		LibraryItem book = new Book("1984", 1949, false, "George Orwell","good");
		
		book.accept(visitor);
		
		assertEquals(book.getTitle()+" is already rented", printer.getMessage());
	}
	
	@Test
	public void testIfBookIsNotRented() {
		LibraryItem book = new Book("1984", 1949, true, "George Orwell","good");
		
		book.accept(visitor);
		
		assertEquals(book.getTitle()+" is not rented", printer.getMessage());
	}
	
	@Test
	public void testIfComicIsNotRented() {
		LibraryItem comic = new Comic("One Piece", 1997, true, "Eichiro Oda", "weekly");
		
		comic.accept(visitor);
		
		assertEquals(comic.getTitle()+" is not rented", printer.getMessage());
	}
	
	@Test
	public void testIfComicIsAlreadyRented() {
		LibraryItem comic = new Comic("One Piece", 1997, false, "Eichiro Oda", "weekly");
		
		comic.accept(visitor);
		
		assertEquals(comic.getTitle()+" is already rented", printer.getMessage());
	}
	
	@Test
	public void testIfVhsIsNotRented() {
		LibraryItem vhs = new Vhs("Cars", 2006, true, false);

		vhs.accept(visitor);
		
		assertEquals(vhs.getTitle()+" is not rented", printer.getMessage());
	}
	
	@Test
	public void testIfVhsIsAlreadyRented() {
		LibraryItem vhs = new Vhs("Cars", 2006, false, false);

		vhs.accept(visitor);
		
		assertEquals(vhs.getTitle()+" is already rented", printer.getMessage());
	}
}
