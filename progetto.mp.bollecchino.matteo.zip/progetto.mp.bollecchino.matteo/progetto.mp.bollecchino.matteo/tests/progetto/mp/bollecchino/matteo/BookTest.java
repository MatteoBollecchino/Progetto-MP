package progetto.mp.bollecchino.matteo;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookTest {

	@Test
	public void testCorrectChangeStateOfBook() {
		Book book = new Book("1984", 1949, false, "George Orwell","good");
		book.changeState("bad");
		assertEquals("bad", book.getState());
	}
	
	@Test
	public void testIncorrectChangeStateOfBook() {
		Book book = new Book("1984", 1949, false, "George Orwell","good");
		book.changeState("GOOD");
		assertEquals("good", book.getState());
	}
}
