package progetto.mp.bollecchino.matteo;

import progetto.mp.bollecchino.matteo.observer.LibraryItemObserver;

public class MockItemObserver implements LibraryItemObserver {
	private LibraryItem item;
	private boolean available;

	@Override
	public void update(LibraryItem item, boolean available) {
		this.item = item;
		this.available = available;
	}
	
	LibraryItem getItem() {
		return item;
	}

	boolean isAvailable() {
		return available;
	}
}
