package progetto.mp.bollecchino.matteo;

import static org.assertj.core.api.Assertions.assertThat; 
import static org.junit.Assert.*; 
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;

public class LibraryTest {
	private LibraryItem book;
	private LibraryItem comic;
	private LibraryItem vhs;
	private Library library;
	private List<LibraryItem> items;
	
	@Before
	public void init() {
		book = new Book("1984", 1949, true, "George Orwell","good");
		comic = new Comic("One Piece", 1997, true, "Eichiro Oda", "weekly");
		vhs = new Vhs("Cars", 2006, true, false);
		items = new ArrayList<LibraryItem>();
		items.add(book);
		items.add(comic);
		items.add(vhs);
		library = new Library.LibraryBuilder("Villa Bandini","Firenze")
				.withItems(items)
				.withOfferSubscription(true)
				.withFloors(1)
				.build();
	}

	@Test
	public void testCorrectLibraryBuilding() {
		assertThat(library.getItems()).contains(book,comic,vhs);
		assertEquals("Villa Bandini",library.getName());
		assertEquals("Firenze",library.getCity());
		assertTrue(library.isOfferSubscription());
		assertEquals(1, library.getFloors());
	}
	
	@Test
	public void testLibraryBuildingWithIncorrectItems() {
		assertThrows(IllegalArgumentException.class, 
				() -> new Library.LibraryBuilder("Villa Bandini","Firenze")
							.withItems(null)
							.build());
	}
	
	@Test
	public void testLibraryBuildingWithIncorrectFloors() {
		assertThrows(IllegalArgumentException.class, 
				() -> new Library.LibraryBuilder("Villa Bandini","Firenze")
							.withFloors(0)
							.build());
		assertThrows(IllegalArgumentException.class, 
				() -> new Library.LibraryBuilder("Villa Bandini","Firenze")
							.withFloors(-10)
							.build());
	}
	
	@Test
	public void testSortingItemsByTitle() {
		library.sortItemsByTitle();
		
		assertThat(library.getItems())
			.isSortedAccordingTo((i1,i2) -> i1.getTitle().compareTo(i2.getTitle()));
	}
	
	@Test
	public void testFindingItemByTitleWithSuccess() {
		assertThat(library.findByTitle("cars"))
			.contains(vhs);
	}
	
	@Test
	public void testFindingItemByTitleWithoutSuccess() {
		assertThat(library.findByTitle("Monsters & co"))
			.isEmpty();
	}
	
	@Test
	public void testFindingItemsByAuthorWithSuccess() {
		Collection<Optional<LibraryItem>> findByAuthor = 
				library.findByAuthor("george orwell",new ArrayList<>());
		
		assertThat(findByAuthor)
			.contains(Optional.of(book));
	}
	
	@Test
	public void testFindingItemsByAuthorWithoutSuccess() {
		assertThat(library.findByAuthor("Kentaro Miura",new ArrayList<>()))
			.isEmpty();
	}
	
	@Test
	public void testFindingAvailableItems() {
		assertThat(library.findAvailableItems())
			.containsExactlyInAnyOrder(book,comic,vhs);
	}
	
	@Test
	public void testNotFindingAvailableItems() {
		book.changeAvailable(false);
		comic.changeAvailable(false);
		vhs.changeAvailable(false);
		assertThat(library.findAvailableItems()).isEmpty();
	}
}
